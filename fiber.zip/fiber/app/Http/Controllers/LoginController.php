<?php

namespace App\Http\Controllers;

use Adldap\Laravel\Facades\Adldap;
use Auth;
use Log;
use Event;
use Illuminate\Support\MessageBag;
use Input;
use Redirect;
use Request;
use Response;
use Session;

class LoginController extends Controller
{

	
	public function username()
	{
		return 'username';
	}
	/**
	 * Process login request
	 *
	 * @return \Illuminate\Http\RedirectResponse
	 */
	public function login()
	{
		$username = Request::get('username');
		$password = Request::get('password');
		$username = strtolower($username);
		
		$userListStr = env('USER_LIST');
		$userList = explode(",",$userListStr);
		
		if(!in_array($username,$userList)) {
			return redirect()->back()->withInput()->with('warning','You do not have permission to use this application. Contact ishelp@cogentco.com if you need it.');
		}
		if (Auth::attempt(['username' => $username, 'password' => $password])) {
//			Auth::user()->setUserPrincipalName($username);
			return redirect()->intended('rings');
		}
		else {
			return redirect()->back()->withInput()->with('warning','Incorrect username or password');
		}
	}
	
	public function logout()
	{
		Auth::logout();
		

		return redirect()->to('/');
	}
//
//	/**
//	 * Forgot password
//	 *
//	 * @return \Illuminate\View\View
//	 */
//	public function forgot()
//	{
//		return $this->view('cogent::login/forgot');
//	}
//
//	/**
//	 * Process logout request
//	 *
//	 * @return \Illuminate\Http\RedirectResponse
//	 */
//	public function logout()
//	{
//		if ( Session::has('impersonate') )
//		{
//			Session::forget('impersonate');
//			Session::forget('impersonateEventFired');
//		}
//		else
//		{
//			Session::forget('username');
//			Auth::logout();
//		}
//
//		return $this->redirect->to('/');
//	}
}