<?php

namespace App\Http\Controllers;

use DB;
use Request;
use App\Models\Ring;
use App\Models\Lateral;

class APIController extends \Illuminate\Routing\Controller
{
    
	public function rings() {
		$data = DB::table('TLG.dbo.RingDetails')
				->select('RingName')
				->get();
		return response()->json($data);
	}
	
	public function laterals() {
		$data = DB::table('TLG.dbo.LateralDetails')
				->select(['LateralDetailsID', 'BuildingID', 'NodeNumber'])
				->get()->all();
		$data = array_map(function($entry) {
			return $entry;
		}, $data);
		
		return response()->json($data);
	}
	
	public function contractStatuses() {
		$data = DB::table('TLG.dbo.ContractStatus')
				->select(['ContractStatusId','ContractStatus'])
				->get();
		return response()->json($data);
	}
	
	public function connectionStatuses() {
		$data = DB::table('TLG.dbo.ConnectionStatus')
				->select(['ConnectionStatusId','ConnectionStatus'])
				->get();
		return response()->json($data);
	}
	
	public function getRingData() {
		
		$ringName = Request::get('RingName');
		//get all the columns on the ring
		$data = Ring::where('RingName',$ringName)->first();
		
		return response()->json($data);
	}
	
	public function currencies() {
		$data = DB::table('dbo.OPM_BillCurrency')->select('CurrencyCode')->where('IsActive',1)->get();
		return response()->json($data);
	}
	
	public function getLateralData() {
		
		$nodeID = Request::get('NodeID');
		if (!strpos($nodeID, '-')) {
			$nodeID .= '-0';
		}
		//related the nodeid to the bobID
		$building = DB::table('mjain.BuildingsExtraCols')->where('NodeId',$nodeID)->select('BoBID')->first();
		
		$bobID = $building->BoBID;
		//return $bobID;
		//get all the columns on the ring
		$data = Lateral::where('BoBID',$bobID)->first();
		//return $data;
		//$data->ActualCost = round($data->ActualCost,2);
		
		return response()->json($data);
	}
	
	public function fiberProviders() {
		$data = DB::table('TLG.dbo.FiberProviders')
				->where('ActiveFlg',1)
				->select(['ProviderID', 
					DB::raw("ProviderName + ' (' + convert(varchar(1000),ProviderID) + ')' as ProviderName")
					])
				->orderBy('ProviderName')
				->get();
		
		return response()->json($data);
	}
	
	public function markets() {
		$ringMarkets = DB::table('TLG.dbo.RingDetails')->select('Market')->distinct()->get()->all();
		
		$tableMarkets = DB::table('TLG.dbo.CogentMarket')->select(DB::raw('CogentMarket as Market'))->get()->all();
		
		
		$ret = [];
		//return $ringMarkets;
		foreach($ringMarkets as $k => $shit) {
			foreach($shit as $k => $market) {
				array_push($ret, trim($market));
			}
		}
		foreach($tableMarkets as $k => $shit) {
			foreach($shit as $k => $market) {
				$market = trim($market);
				if (!in_array($market,$ret)) {
					array_push($ret, $market);
				}
			}
		}
		sort($ret);
		return $ret;
		
	}
	
	
	public function ringNameAuto() {
		$fragment = Request::get('term');
		$data = Ring::whereRaw("RingName like '%$fragment%'")->orderBy('RingName')->select([DB::raw("RingName as label"), DB::raw("RingName as value")])->get();
		return response()->json($data);
	}
	
	
}
