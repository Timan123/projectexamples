<?php 


namespace App\Http\Controllers;

use DB;
use Auth;
use Box\Spout\Reader\ReaderFactory;
use Box\Spout\Common\Type;
use Carbon\Carbon;
use Validator;
use Redirect;
use Request;
use Log;
use Session;

class PageController extends Controller {
	
	public function login() {
		
			
		if ( Auth::check() )
		{
			//$user = Auth::user()->getAccountName();
			return redirect()->to('/');
		}

		return view('login',[]);
	}
	
	public function rings() {
		
		$indexNum = Request::get('IndexNum');
		$ringPassIn = Request::get('RingPassIn');
		
		if (!$indexNum) {
			$indexNum = 'null';
		}
		if (!$ringPassIn) {
			$ringPassIn = 'null';
		} else {
			$ringPassIn = "'" . $ringPassIn .  "'";
		}
		return view('rings', ['IndexNum' => $indexNum, 'RingPassIn' => $ringPassIn] );
    }
	
	public function laterals() {
		
		$bobID = Request::get('BoBID');
//		if (!$bobID) {
//			$bobID = 'null';
//		}
		return view('laterals', ['BoBID' => $bobID] );
    }
	
	
}