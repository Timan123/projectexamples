<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Http\Controllers;

use Log;
use Auth;
use Request;
use Session;
use Redirect;
use App\Models\Ring;
use App\Models\Lateral;

/**
 * Description of ActionController
 *
 * @author tcassidy
 */
class ActionController extends \Illuminate\Routing\Controller {
	
	public function saveLateral() {
		$params = Request::all();
		
		$lateralDetailsID = Request::get('LateralDetailsID');
		$bobID = Request::get('BoBID');
		$nodeID = Request::get('NodeID');
		
		Log::info($params);
		unset($params['LateralDetailsID']);
		unset($params['NodeID']);
		unset($params['_token']);
		unset($params['BoBID']);
		
		//tag it with the logged in username
		$params['LastUpdtUser'] = Auth::user()->getAccountName();
		
		$lateral = Lateral::find($lateralDetailsID);
		$lateral->fill($params);
		$lateral->save();
		
		$nodeID = $lateral->BuildingID . '-' . $lateral->NodeNumber;
		
		$message = 'Lateral updated!';
		return Redirect::route('laterals.index', [ 'BoBID' => $nodeID ])->with('message',$message);
	}
	
	
	public function saveRing() {
	
		$params = Request::all();
		
		$indexNum = Request::get('IndexNum');
		
		unset($params['render']);
		unset($params['newFlag']);
		unset($params['_token']);
		unset($params['IndexNum']);
		//tag it with the logged in username
		$params['LastUpdtUser'] = Auth::user()->getAccountName();
		
		$message = 'created!';
		if (!$indexNum) {
			$isNew = true;
		} else {
			$message = 'updated!';
		}
		
		
		$ring = Ring::findOrNew($indexNum);
		
		
		
		$ring->fill($params);
		
		$ring->save();
		$index = $ring->getKey();
		$ringName = $ring->RingName;
		$fullMessage = 'Ring ' . $message;
		
		return Redirect::route('rings.index', [ 'IndexNum' => $index, 'RingPassIn' => $ringName ])->with('message',$fullMessage);
	}
}
