<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Ring extends Model
{
    protected $table = 'RingDetails';
	
	protected $primaryKey = 'IndexNum';
	
	const UPDATED_AT = 'LastUpdtDt';
	
	const CREATED_AT = null;
	
	protected $dateFormat = 'Y-m-d H:i:s';
	
	protected $appends = [ 'OandM', 'NRC', 'MRC' ];
	
	//allow mass assignment
	protected $guarded = [];
	
	public function getOandMAttribute()
	{
		return round($this->getAttributeFromArray('OandM'), 2);
	}
	public function getMRCAttribute()
	{
		return round($this->getAttributeFromArray('MRCs'), 2);
	}
	public function getNRCAttribute()
	{
		return round($this->getAttributeFromArray('NRC'), 2);
	}
	
	
}
