<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Lateral extends Model
{
    protected $table = 'LateralDetails';
	
	protected $primaryKey = 'LateralDetailsID';
	
	const UPDATED_AT = 'LastUpdtDt';
	
	const CREATED_AT = null;
	
	protected $appends = [ 'EstCost', 'ActualCost' ];
	
	protected $dateFormat = 'Y-m-d H:i:s';
	
	//allow mass assignment
	protected $guarded = [];
	
	public function getEstCostAttribute()
	{
		return round($this->getAttributeFromArray('EstCost'), 2);
	}
	public function getActualCostAttribute()
	{
		return round($this->getAttributeFromArray('ActualCost'), 2);
	}
}
