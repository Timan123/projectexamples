@extends("template")

@section('title')
Fiber - Rings
@stop

@section('scripts')
		<script type="text/javascript">
var vm1 =	new Vue({
	el: '#main',
	data: {
		theRing: '',
		mrcPayFreqs: ['', 'Annually', 'Monthly', 'N/A', 'PIF', 'Quarterly', 'SemiAnnual'],
		oAndMPayFreqs:  ['', 'Annually', 'Monthly', 'N/A', 'No O&M', 'PIF', 'Quarterly'],
		ringText: '',
		indexNum: {{$IndexNum}},
		ringPassIn: {!! $RingPassIn !!},
		emptyRing: {
			'RingName': null,
			'FiberProvider': null,
			'NumberOfFibersPurchased': 0,
			'RouteMiles': 0,
			'TotalFiberMiles': 0,
			'NRC': 0,
			'NRCPaidToDt': null,
			'MRC': 0,
			'Term': 0,
			'MRCPayFreq': null,
			'OandM': null,
			'OandMPayFreq': null,
			'PONumber': null,
			'PackageAcceptanceDt': null,
			'PurchasedDt': null,
			'HubBID': null,
			'NodeNumber': null,
			'RingToHubConnectionDt': null,
			'RingToHubConnectionStatus': null,
			'Market': null,
			'Region': null,
			'Reach': null,
			'HubCode': null,
			'Purchased': 'Y',
			'render': true,
			'newFlag': true,
			'IndexNum': null
		},
		ringData: { 'render': false },
		fiberProviders: [],
		markets: [],
		regions: ['','NA','EU','AS'],
		currencies: []
	},
	mounted: function mounted() {
		var self = this;
		$.ajax({
			url: 'api/markets',
			method: 'GET',
			success: function success(data) {
				self.markets = data;
			}
		});
		$.ajax({
			url: 'api/fiberProviders',
			method: 'GET',
			success: function success(data) {
				self.fiberProviders = data;
			}
		});
		$.ajax({
			url: 'api/currencies',
			method: 'GET',
			success: function success(data) {
				self.currencies = data;
			}
		});
		
	},
	computed: {
		totalFiberFiles: function totalFiberFiles() {
			var nofp = this.ringData.RouteMiles * this.ringData.NumberOfFibersPurchased;
			return nofp.toFixed(5);
		}
	},
	created: function created() {
		if (this.indexNum) {
			this.theRing = this.ringPassIn;
			this.displayRing();
		}
	},
	methods: {
		displayRing: function displayRing() {
			if (!this.theRing) {
				return;
			}
			var self = this;
			$.ajax({
				url: 'api/getRingData?RingName=' + this.theRing,
				method: 'GET',
				success: function success(data) {
					if (data.RingName) {
						self.ringData = data;
						self.ringData.render = true;
						self.newFlag = false;
					} else {
						self.ringData = self.emptyRing;
						self.ringData.render = false;
					}
				}
			});
		},
		newRing: function newRing() {
			this.theRing = '';
			this.ringData = this.emptyRing;
			this.ringData.render = true;
		}
	},
});



$( document ).ready(function() {
	
	
    $("#ringAuto").autocomplete({
		source: "api/ringNameAuto",
		select: function( event, ui ) {
			//hack needed for IE only to bind it to the vm
			Vue.set(vm1, 'theRing', ui.item.value);
		}
	});
});


		</script>
@stop
@section('content')
@parent
<h1>Rings</h1>

Choose a ring: <input type="text" id="ringAuto" class="form-control input-sm form-control-lite" v-model="theRing" v-on:keyup.enter="displayRing"/>
&nbsp;&nbsp;<button class="btn btn-sm btn-primary" v-on:click="displayRing">Go</button>
&nbsp;&nbsp;<button class="btn btn-sm btn-primary" v-on:click="newRing">Create New Ring</button>



<br><br>
<div id="ringDiv" v-if="ringData.render">
	<form id="ringForm" method="post" action="rings">
		{{ csrf_field() }}
	<input type="hidden" name="IndexNum" v-model="ringData.IndexNum">	
	<div class="row">
		<div class="col-md-2 form-group">
			<label class="control-label" for="RingName">Ring Name:</label>
			<input type="text" name="RingName" required class="form-control input-sm input-smaller" v-model="ringData.RingName">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="FiberProvider">Fiber Provider:</label>
			<select required type="text" name="FiberProvider" class="form-control input-sm input-smaller" v-model="ringData.FiberProvider">
				<option v-for="fb in fiberProviders" v-bind:value="fb.ProviderID">
					@{{ fb.ProviderName }}
				</option>
			</select>
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="NumFibers">Num Fibers:</label>
			<input type="text" name="NumberOfFibersPurchased" class="form-control input-sm input-smaller" v-model="ringData.NumberOfFibersPurchased">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="RouteMiles">Route Miles:</label>
			<input type="text" name="RouteMiles" class="form-control input-sm input-smaller" v-model="ringData.RouteMiles">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="TotalFiberMiles">Total Fiber Miles:</label>
			<span class="input-sm input-smaller no-border form-control" v-text="totalFiberFiles"></span>
			<input type="hidden" name="TotalFiberMiles" class="form-control input-sm input-smaller" v-model="totalFiberFiles">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="PONumber">PO Number:</label>
			<input type="text" name="PONumber" class="form-control input-sm input-smaller" v-model="ringData.PONumber">
		</div>
	</div>
	<div class="row">
		<div class="col-md-2 form-group">
			<label class="control-label" for="NRC">NRC:</label>
			<input type="text" name="NRC" class="form-control input-sm input-smaller" v-model="ringData.NRC">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="MRC">MRC:</label>
			<input type="text" name="MRC" class="form-control input-sm input-smaller" v-model="ringData.MRC">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="Currency">Currency:</label>
			<select required type="text" name="Currency" class="form-control input-sm input-smaller" v-model="ringData.Currency">
				<option v-for="currency in currencies" v-bind:value="currency.CurrencyCode">
					@{{ currency.CurrencyCode }}
				</option>
			</select>
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="Term">Term:</label>
			<input type="text" name="Term" class="form-control input-sm input-smaller" v-model="ringData.Term">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="MRCPayFreq">MRC Pay Freq:</label>
			<select required type="text" name="MRCPayFreq" class="form-control input-sm input-smaller" v-model="ringData.MRCPayFreq">
				<option v-for="mpf in mrcPayFreqs" v-bind:value="mpf">
					@{{ mpf }}
				</option>
			</select>
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="Reach">Reach:</label>
			<select type="text" name="Reach" class="form-control input-sm input-smaller" v-model="ringData.Reach">
				<option value=""></option>
				<option value="Metro">Metro</option>
				<option value="Longhaul">Longhaul</option>
			</select>
		</div>
	</div>
	<div class="row">
		<div class="col-md-2 form-group">
			<label class="control-label" for="OandM">O & M:</label>
			<input type="text" name="OandM" class="form-control input-sm input-smaller" v-model="ringData.OandM">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="OandMPayFreq">O & M Pay Freq:</label>
			<select required type="text" name="OandMPayFreq" class="form-control input-sm input-smaller" v-model="ringData.OandMPayFreq">
				<option v-for="opf in oAndMPayFreqs" v-bind:value="opf">
					@{{ opf }}
				</option>
			</select>
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="PurchasedDt">Purchased Date:</label>
			<input type="text" id="PurchasedDt" name="PurchasedDt" class="form-control input-sm input-smaller" v-model="ringData.PurchasedDt">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="PackageAcceptanceDt">Package Acceptance Dt:</label>
			<input type="text" name="PackageAcceptanceDt" class="form-control input-sm input-smaller date" v-model="ringData.PackageAcceptanceDt">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="HubBID">Building ID:</label>
			<input type="text" name="HubBID" class="form-control input-sm input-smaller" v-model="ringData.HubBID">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="NodeNumber">Node Number:</label>
			<input type="text" name="NodeNumber" class="form-control input-sm input-smaller" v-model="ringData.NodeNumber">
		</div>
	</div>
	<div class="row">
		<div class="col-md-2 form-group">
			<label class="control-label" for="RingToHubConnectionStatus">Ring-Hub Conn Status:</label>
			<input type="text" name="RingToHubConnectionStatus" class="form-control input-sm input-smaller" v-model="ringData.RingToHubConnectionStatus">
		</div>
		
		<div class="col-md-2 form-group">
			<label class="control-label" for="Market">Market:</label>
			<select required type="text" name="Market" class="form-control input-sm input-smaller" v-model="ringData.Market">
				<option v-for="market in markets" v-bind:value="market">
					@{{ market }}
				</option>
			</select>
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="Region">Region:</label>
			<select required type="text" name="Region" class="form-control input-sm input-smaller" v-model="ringData.Region">
				<option v-for="regionOp in regions" v-bind:value="regionOp">
					@{{ regionOp }}
				</option>
			</select>
		</div>
		
		<div class="col-md-2 form-group">
			<label class="control-label" for="HubCode">Hub Code:</label>
			<input type="text" name="HubCode" class="form-control input-sm input-smaller" v-model="ringData.HubCode">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="Purchased">Purchased:</label>
			<input type="text" name="Purchased" class="form-control input-sm input-smaller" v-model="ringData.Purchased">
		</div>
	</div>
	<div class="row">
		<div class="col-md-2 form-group">
			<label class="control-label" for="LastUpdtUser">Last Updt User:</label>
			<span class="input-sm input-smaller no-border form-control" v-text="ringData.LastUpdtUser"></span>
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="LastUpdtDt">Last Updt Dt:</label>
			<span class="input-sm input-smaller no-border form-control" v-text="ringData.LastUpdtDt"></span>
		</div>
	</div>
	<input type="submit" class="btn btn-sm btn-primary" value="Submit">
	</form>
</div>


@stop