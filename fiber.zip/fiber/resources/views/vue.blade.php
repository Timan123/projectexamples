@extends("template")

@section('title')
Fiber - Vue
@stop

@section('scripts')
		<script type="text/javascript">
			new Vue({
				el: '#main',
				data: {
					firstName: 'Tyler',
					lastName: 'Cassidy',
				}, 
				computed: {
					fullName() {
						return this.firstName + ' ' + this.lastName;
					}
				}
			})
		</script>
@stop
@section('content')
@parent
<h1>Vue</h1>
First name: <input type="text" v-model="firstName"><br>
Last name: <input type="text" v-model="lastName">
<br>
The full name is is @{{fullName}}



@stop