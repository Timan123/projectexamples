@extends("template")

@section('title')
Fiber - Vue
@stop

@section('scripts')
		<script type="text/javascript">
			new Vue({
				el: '#main',
				data: {
					orders: []
				},
				mounted() {
					var self = this;
					$.ajax({
						url: 'api/rings',
						method: 'GET',
						success: function (data) {
							self.orders = data;
						}
					});
				},
			})
		</script>
@stop
@section('content')
@parent
<h1>Orders</h1><br>
<table class="table table-striped 
	table-responsive table-condensed small">
	<thead>
		<tr>
			<th>OrderId</th>
			<th>Account</th>
			<th>Status</th>
			<th>Created</th>
		</tr>
	</thead>
	<tbody>
		<tr v-for="order in orders">
			<td>@{{order.Order_Num}}</td>
			<td>@{{order.Account}}</td>
			<td>@{{order.Status}}</td>
			<td>@{{order.Created}}</td>
		</tr>
	</tbody>
</table>






@stop