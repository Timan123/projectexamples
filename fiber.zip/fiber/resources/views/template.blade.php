<!DOCTYPE HTML>
<html>
<head>

	
	
	@section('title') Cogent @stop
	@section('brand-title') Cogent @stop
	@section('containerClass'){{ (isset($useFluidContainer) && $useFluidContainer === true) ? 'container-fluid' : 'container' }}@stop

	@section('cssCacheBuster')
	

	@include('header')

	@section('meta')
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="Cogent">
	<meta name="description" content="Cogent">
	<link rel="shortcut icon" href="favicon.png">
	@stop

	<title>{{ trim(View::yieldContent('title')) }}</title>
	@yield('meta')

	
	
</head>
<body>
	<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
		<div class="{{ trim(View::yieldContent('containerClass')) }}">
			<div class="navbar-header">
				<a href="/" class="navbar-brand">Fiber</a>
			</div>
			<div id="navbar" class="navbar-collapse collapse">
				<ul class="nav navbar-nav">
				    <li {{{ (Request::is('rings') ? 'class=active' : '') }}}>
					    <a href="rings">Rings</a>
				    </li>
					<li  {{{ (Request::is('laterals') ? 'class=active' : '') }}}>
					    <a href="laterals">Laterals</a>
				    </li>

				</ul>
				<ul class="nav navbar-nav pull-right">
					@if( !Auth::check() )
					<li>
						<a href="login" >Login</a>
					</li>
					@else
					
					<li>
						<a aria-expanded="false" href="#" class="dropdown-toggle" data-toggle="dropdown">
							<span class="glyphicon glyphicon-user"></span> {{{ Auth::user()->getCommonName() }}} 
						</a>
					</li>	
					<li>
						<a href="logout"><span class="glyphicon glyphicon-share fa-fw"></span>Logout</a>
					</li>
					@endif
				</ul>
			</div>

		</div>
	</nav>

	<div class="{{ trim(View::yieldContent('containerClass')) }}" id="main">
		@yield('content')
		
		
		
		
	</div>

	<footer class="{{ trim(View::yieldContent('containerClass')) }}">
		@section('footer')
		@if(session()->has('message'))
		<div class="alert alert-success">
			{{ session()->get('message') }}
		</div>	
		@endif
		@if(session()->has('warning'))
		<div class="alert alert-warning">
			{{ session()->get('warning') }}
		</div>	
		@endif
		<p class="text-center">
			&copy; {{ \Carbon\Carbon::now()->year }} Cogent Communications, Inc.
			@if( defined('VERSION') )
			|&nbsp; v{{ constant('VERSION') }}
			@endif
		</p>
		@stop

		@yield('footer')
	</footer>

	@yield('scripts')
</body>
</html>