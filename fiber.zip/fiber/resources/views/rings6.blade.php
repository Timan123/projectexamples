@extends("template")

@section('title')
Fiber - Rings
@stop

@section('scripts')
		<script type="text/javascript">
			new Vue({
				el: '#main',
				data: {
					theRing: '',
					ringText: '',
					emptyRing: {
						'RingName' : null,
						'FiberProvider' : null,
						'NumberOfFibersPurchased' : 0,
						'NumberOfStrands' : 0,
						'RouteMiles' : 0,
						'TotalFiberMiles' : 0,
						'CostPerMile' : null,
						'NRC' : 0,
						'NRCPaidToDt' : null,
						'MRC' : 0,
						'Term' : 0,
						'MRCPayFreq' : null,
						'OandM' : null,
						'OandMPayFreq' : null,
						'PONumber' : null,
						'PackageAcceptanceDt' : null,
						'PurchasedDt' : null,
						'HubBID' : null,
						'NodeNumber' : null,
						'RingToHubConnectionDt' : null,
						'RingToHubConnectionStatus' : null,
						'Market' : null,
						'Region' : null,
						'Reach' : null,
						'HubCode' : null,
						'Purchased' : 'N'
					},
					ringData: {'render':false},
					allRings: [],
					fiberProviders: []
				}, 
				methods: {
					displayRing() {
						if (!this.theRing) {
							return;
						}
						var self = this;
						$.ajax({
							url: 'api/getRingData?RingName=' + this.theRing,
							method: 'GET',
							success: function (data) { 
								self.ringData = data; 
								self.ringData.render = true;
							}
						});
					},
					newRing() {
						this.ringData = this.emptyRing;
						this.ringData.render = true;
					},
					test() {
						//Vue.set(this.ringData, 'CostPerMile', 5);
						this.ringData.CostPerMile = 5;
					},
					saveRing() {
//						event.stopPropagation();
//						event.preventDefault();
						var data = this.ringData;
						$.ajax({
							url: 'api/saveRing',
							type: 'POST',
							headers: {
								'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
							},
							data: data,
							cache: false,
							dataType: 'json',
							success: function(data, textStatus, jqXHR) {

							}
						});
						return false;
					}
				},
				mounted() {
					var self = this;
					$.ajax({
						url: 'api/rings',
						method: 'GET',
						success: function (data) { self.allRings = data; }
					});
					$.ajax({
						url: 'api/fiberProviders',
						method: 'GET',
						success: function (data) { self.fiberProviders = data; }
					});
				},
			});
			
			$(function() {
				$("#ringAuto").autocomplete({      
					source: "api/ringNameAuto"
				});
			});
		</script>
@stop
@section('content')
@parent
<h1>Rings</h1>

Choose a ring: <input type="text" id="ringAuto" class="form-control input-sm form-control-lite" v-model="theRing">
&nbsp;&nbsp;<button class="btn btn-sm btn-primary" v-on:click="displayRing">Go</button>
&nbsp;&nbsp;<button class="btn btn-sm btn-primary" v-on:click="newRing">Create New Ring</button><button class="btn btn-sm btn-primary" v-on:click="test">Test</button>



<br><br>
<div id="ringDiv" v-if="ringData.render">
	<form id="ringForm" v-on:submit.prevent="saveRing">
	<div class="row">
		<div class="col-md-2 form-group">
			<label class="control-label" for="RingName">Ring Name:</label>
			<input type="text" name="RingName" required class="form-control input-sm input-smaller" v-model="ringData.RingName">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="FiberProvider">Fiber Provider:</label>
			<select type="text" name="FiberProvider" class="form-control input-sm input-smaller" v-model="ringData.FiberProvider">
				<option v-for="fb in fiberProviders" v-bind:value="fb.ProviderID">
					@{{ fb.ProviderName }}
				</option>
			</select>
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="NumFibers">Num Fibers:</label>
			<input type="text" name="NumberOfFibersPurchased" class="form-control input-sm input-smaller" v-model="ringData.NumberOfFibersPurchased">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="NumberOfStrands">Num Strands:</label>
			<input type="text" name="NumberOfStrands" class="form-control input-sm input-smaller" v-model="ringData.NumberOfStrands">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="RouteMiles">Route Miles:</label>
			<input type="text" name="RouteMiles" class="form-control input-sm input-smaller" v-model="ringData.RouteMiles">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="TotalFiberMiles">Total Fiber Miles:</label>
			<input type="text" name="TotalFiberMiles" class="form-control input-sm input-smaller" v-model="ringData.TotalFiberMiles">
		</div>
	</div>
	<div class="row">
		<div class="col-md-2 form-group">
			<label class="control-label" for="CostPerMile">Cost Per Mile:</label>
			<input type="text" name="CostPerMile" class="form-control input-sm input-smaller" v-model="ringData.CostPerMile">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="NRC">NRC:</label>
			<input type="text" name="NRC" class="form-control input-sm input-smaller" v-model="ringData.NRC">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="MRC">MRC:</label>
			<input type="text" name="MRC" class="form-control input-sm input-smaller" v-model="ringData.MRC">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="Term">Term:</label>
			<input type="text" name="Term" class="form-control input-sm input-smaller" v-model="ringData.Term">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="MRCPayFreq">MRC Pay Freq:</label>
			<input type="text" name="Term" class="form-control input-sm input-smaller" v-model="ringData.MRCPayFreq">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="PurchasedDt">Purchased Date:</label>
			<input type="text" name="PurchasedDt" class="form-control input-sm input-smaller" v-model="ringData.PurchasedDt">
		</div>
	</div>
	<div class="row">
		<div class="col-md-2 form-group">
			<label class="control-label" for="OandM">O & M:</label>
			<input type="text" name="OandM" class="form-control input-sm input-smaller" v-model="ringData.OandM">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="OandMPayFreq">O & M Pay Freq:</label>
			<input type="text" name="OandMPayFreq" class="form-control input-sm input-smaller" v-model="ringData.OandMPayFreq">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="PONumber">PO Number:</label>
			<input type="text" name="PONumber" class="form-control input-sm input-smaller" v-model="ringData.PONumber">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="PackageAcceptanceDt">Package Acceptance Dt:</label>
			<input type="text" name="PackageAcceptanceDt" class="form-control input-sm input-smaller" v-model="ringData.PackageAcceptanceDt">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="HubBID">Hub ID:</label>
			<input type="text" name="HubBID" class="form-control input-sm input-smaller" v-model="ringData.HubBID">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="NodeNumber">Node Number:</label>
			<input type="text" name="NodeNumber" class="form-control input-sm input-smaller" v-model="ringData.NodeNumber">
		</div>
	</div>
	<div class="row">
		<div class="col-md-2 form-group">
			<label class="control-label" for="RingToHubConnectionStatus">Ring-Hub Conn Status:</label>
			<input type="text" name="RingToHubConnectionStatus" class="form-control input-sm input-smaller" v-model="ringData.RingToHubConnectionStatus">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="Market">Market:</label>
			<input type="text" name="Market" class="form-control input-sm input-smaller" v-model="ringData.Market">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="Region">Region:</label>
			<input type="text" name="Region" class="form-control input-sm input-smaller" v-model="ringData.Region">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="Reach">Reach:</label>
			<select type="text" name="Reach" class="form-control input-sm input-smaller" v-model="ringData.Reach">
				<option value=""></option>
				<option value="Metro">Metro</option>
				<option value="Longhaul">Longhaul</option>
			</select>
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="HubCode">Hub Code:</label>
			<input type="text" name="HubCode" class="form-control input-sm input-smaller" v-model="ringData.HubCode">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="Purchased">Purchased:</label>
			<input type="text" name="Purchased" class="form-control input-sm input-smaller" v-model="ringData.Purchased">
		</div>
	</div>
	<div class="row">
		<div class="col-md-2 form-group">
			<label class="control-label" for="LastUpdtUser">Last Updt User:</label>
			<span class="input-sm input-smaller no-border form-control" v-text="ringData.LastUpdtUser"></span>
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="LastUpdtDt">Last Updt Dt:</label>
			<span class="input-sm input-smaller no-border form-control" v-text="ringData.LastUpdtDt"></span>
		</div>
	</div>
	<input type="submit" class="btn btn-sm btn-primary" value="Submit">
	</form>
</div>


@stop