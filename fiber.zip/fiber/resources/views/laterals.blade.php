@extends("template")

@section('title')
Fiber - Laterals
@stop

@section('scripts')
		<script type="text/javascript">
var vm1 =	new Vue({
	el: '#main',
	data: {
		nodeID: {!! json_encode($BoBID) !!},
		lateralText: '',
		lateralData: { 'render': false },
		allLaterals: [],
		fiberProviders: [],
		contractStatuses: [],
		connectionStatuses: [],
		permitStatuses: [	
			{'PermitStatusID': 'N', 'PermitStatus': 'None'},
			{'PermitStatusID': 'PG', 'PermitStatus': 'Permit Granted'},
			{'PermitStatusID': 'PR', 'PermitStatus': 'Permit Requested'}
		],
		currencies: []
	},
	created: function created() {
		if (this.nodeID) {
			this.displayLateral();
		}
	},
	mounted: function mounted() {
		var self = this;
		$.ajax({
			url: 'api/fiberProviders',
			method: 'GET',
			success: function success(data) {
				self.fiberProviders = data;
			}
		});
		$.ajax({
			url: 'api/contractStatuses',
			method: 'GET',
			success: function success(data) {
				self.contractStatuses = data;
			}
		});
		$.ajax({
			url: 'api/connectionStatuses',
			method: 'GET',
			success: function success(data) {
				self.connectionStatuses = data;
			}
		});
		$.ajax({
			url: 'api/currencies',
			method: 'GET',
			success: function success(data) {
				self.currencies = data;
			}
		});

	},
	methods: {
		displayLateral: function displayLateral() {
			if (!this.nodeID) {
				return;
			}
			var self = this;
			$.ajax({
				url: 'api/getLateralData?NodeID=' + this.nodeID,
				method: 'GET',
				success: function success(data) {
					if (data.LateralDetailsID) {
						self.lateralData = data;
						self.lateralData.render = true;
					} else {
						self.lateralData = { 'render': false };
					}
				},
				error: function error() {
					self.lateralData = { 'render': false };
				}
			});
		}
	},
});


		</script>
@stop
@section('content')
@parent
<h1>Laterals</h1>

Enter a BuildingID (without -0) or full NodeID: <input type="text" id="lateralAuto" class="form-control input-sm form-control-lite" v-model="nodeID" v-on:keyup.enter="displayLateral"/>
&nbsp;&nbsp;<button class="btn btn-sm btn-primary" v-on:click="displayLateral">Go</button>



<br><br>
<div id="lateralDiv" v-if="lateralData.render">
	<form id="lateralForm" method="post" action="laterals">
		{{ csrf_field() }}
	<input type="hidden" name="LateralDetailsID" v-model="lateralData.LateralDetailsID">	
	<input type="hidden" name="BoBID" v-model="lateralData.BoBID">
	<div class="row">
		<div class="col-md-2 form-group">
			<label class="control-label" for="LateralProviderID">Lateral Provider:</label>
			<select required type="text" name="LateralProviderID" class="form-control input-sm input-smaller" v-model="lateralData.LateralProviderID">
				<option v-for="fb in fiberProviders" v-bind:value="fb.ProviderID">
					@{{ fb.ProviderName }}
				</option>
			</select>
		</div>
		
		<div class="col-md-2 form-group">
			<label class="control-label" for="ContractStatusDt">Contract Status Dt:</label>
			<input type="text" name="ContractStatusDt" class="form-control input-sm input-smaller" v-model="lateralData.ContractStatusDt">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="ConnectionStatus">Connection Status:</label>
			<select required type="text" name="ConnectionStatus" class="form-control input-sm input-smaller" v-model="lateralData.ConnectionStatus">
				<option v-for="conns in connectionStatuses" v-bind:value="conns.ConnectionStatusId">
					@{{ conns.ConnectionStatus }}
				</option>
			</select>
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="ConnectionStatusDt">Connection Status Dt:</label>
			<input type="text" name="ConnectionStatusDt" class="form-control input-sm input-smaller" v-model="lateralData.ConnectionStatusDt">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="PermitStatus">Permit Status:</label>
			<select type="text" name="PermitStatus" class="form-control input-sm input-smaller" v-model="lateralData.PermitStatus">
				<option v-for="ps in permitStatuses" v-bind:value="ps.PermitStatusID">
					@{{ ps.PermitStatus }}
				</option>
			</select>
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="Length">Length:</label>
			<input type="text" name="Length" class="form-control input-sm input-smaller" v-model="lateralData.Length">
		</div>
		
		
	</div>
	<div class="row">
		<div class="col-md-2 form-group">
			<label class="control-label" for="CogentOwned">Cogent Owned?:</label>
			<input type="text" name="CogentOwned" class="form-control input-sm input-smaller" v-model="lateralData.CogentOwned">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="CogentPONumber">PO Number:</label>
			<input type="text" name="CogentPONumber" class="form-control input-sm input-smaller" v-model="lateralData.CogentPONumber">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="MRC">MRC:</label>
			<input type="text" name="MRC" class="form-control input-sm input-smaller" v-model="lateralData.MRC">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="NRC">NRC:</label>
			<input type="text" name="NRC" class="form-control input-sm input-smaller" v-model="lateralData.NRC">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="Currency">Currency:</label>
			<select type="text" name="Currency" class="form-control input-sm input-smaller" v-model="lateralData.Currency">
				<option v-for="currency in currencies" v-bind:value="currency.CurrencyCode">
					@{{ currency.CurrencyCode }}
				</option>
			</select>
		</div>
		
	</div>
	<hr>
	<div class="row">
		<div class="col-md-2 form-group">
			<label class="control-label" for="Contractor">Contractor:</label>
			<input type="text" name="Contractor" class="form-control input-sm input-smaller" v-model="lateralData.Contractor">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="ContractStatus">Contract Status:</label>
			<select required type="text" name="ContractStatus" class="form-control input-sm input-smaller" v-model="lateralData.ContractStatus">
				<option v-for="cs in contractStatuses" v-bind:value="cs.ContractStatusId">
					@{{ cs.ContractStatus }}
				</option>
			</select>
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="EstCost">Est Cost:</label>
			<input type="text" name="EstCost" class="form-control input-sm input-smaller" v-model="lateralData.EstCost">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="ActualCost">Actual Cost:</label>
			<input type="text" name="ActualCost" class="form-control input-sm input-smaller" v-model="lateralData.ActualCost">
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="HUB">Hub Code:</label>
			<input type="text" name="HUB" class="form-control input-sm input-smaller" v-model="lateralData.HUB">
		</div>
	</div>
	<div class="row">
		<div class="col-md-2 form-group">
			<label class="control-label" for="LastUpdtUser">Last Updt User:</label>
			<span class="input-sm input-smaller no-border form-control" v-text="lateralData.LastUpdtUser"></span>
		</div>
		<div class="col-md-2 form-group">
			<label class="control-label" for="LastUpdtDt">Last Updt Dt:</label>
			<span class="input-sm input-smaller no-border form-control" v-text="lateralData.LastUpdtDt"></span>
		</div>
	</div>
		
	
	<input type="submit" class="btn btn-sm btn-primary" value="Submit">
	</form>
</div>


@stop