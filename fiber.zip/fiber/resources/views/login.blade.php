@extends("template")


@section('title')
Fiber - Login
@stop

@section("content")
@parent
<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
	<h1>Login</h1>
	{{ Form::open([ 'route' => 'login', 'method' => 'post', 'role' => 'form' ]) }}
	
		<div class="form-group">
			{{ Form::label("username", 'Username', [ 'class' => "control-label sr-only" ]) }}
			{{ Form::text("username", null, [ 'class' => "form-control", 'placeholder' => 'Username' ]) }}
		</div>

		<div class="form-group">
			{{ Form::label("password", 'Password', [ 'class' => "control-label sr-only" ]) }}
			{{ Form::password("password", [ 'class' => "form-control", 'placeholder' => 'Password' ]) }}
		</div>

		<div class="form-group">
			{{ Form::submit('Submit', [ "class" => "btn btn-primary btn-block" ]) }}
		</div>

		
	{{ Form::close() }}
</div>
@stop