@extends("template")

@section('title')
Fiber - Vue
@stop

@section('scripts')
		<script type="text/javascript">
			new Vue({
				el: '#main',
				data: {
					message: 'message',
					tasks: [
						{description: 'Go to the store', completed: false},
						{description: 'other thing', completed: true}
					]
				}, 
				methods: {
					addName() {
						alert('pushed');
					}
				},
				computed: {
					incompleteTasks() {
						this.myprop = 20;
						return this.tasks.filter(task => alert(this.myprop));
					}
				}
			})
		</script>
@stop
	

@section('content')
@parent
<h1>Vue</h1><br>


<button @click="addName">JS Stuff</button>

<ul>
	<li v-for="task in incompleteTasks" v-text="task.description"></li>
</ul>




@stop