<?php $__env->startSection('title'); ?>
Fiber - Vue
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
		<script type="text/javascript">
			new Vue({
				el: '#main',
				data: {
					firstName: 'Tyler',
					lastName: 'Cassidy',
				}, 
				computed: {
					fullName() {
						return this.firstName + ' ' + this.lastName;
					}
				}
			})
		</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
##parent-placeholder-040f06fd774092478d450774f5ba30c5da78acc8##
<h1>Vue</h1>
First name: <input type="text" v-model="firstName"><br>
Last name: <input type="text" v-model="lastName">
<br>
The full name is is {{fullName}}



<?php $__env->stopSection(); ?>
<?php echo $__env->make("template", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>