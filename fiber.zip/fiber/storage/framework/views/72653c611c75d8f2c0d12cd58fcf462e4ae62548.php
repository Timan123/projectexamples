<?php $__env->startSection('title'); ?>
Fiber - Login
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
##parent-placeholder-040f06fd774092478d450774f5ba30c5da78acc8##
<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
	<h1>Login</h1>
	<?php echo e(Form::open([ 'route' => 'login', 'method' => 'post', 'role' => 'form' ])); ?>

	
		<div class="form-group">
			<?php echo e(Form::label("username", 'Username', [ 'class' => "control-label sr-only" ])); ?>

			<?php echo e(Form::text("username", null, [ 'class' => "form-control", 'placeholder' => 'Username' ])); ?>

		</div>

		<div class="form-group">
			<?php echo e(Form::label("password", 'Password', [ 'class' => "control-label sr-only" ])); ?>

			<?php echo e(Form::password("password", [ 'class' => "form-control", 'placeholder' => 'Password' ])); ?>

		</div>

		<div class="form-group">
			<?php echo e(Form::submit('Submit', [ "class" => "btn btn-primary btn-block" ])); ?>

		</div>

		
	<?php echo e(Form::close()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("template", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>