<?php $__env->startSection('title'); ?>
Fiber - Vue
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
		<script type="text/javascript">
			new Vue({
				el: '#main',
				data: {
					orders: []
				},
				mounted() {
					var self = this;
					$.ajax({
						url: 'api/rings',
						method: 'GET',
						success: function (data) {
							self.orders = data;
						}
					});
				},
			})
		</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
##parent-placeholder-040f06fd774092478d450774f5ba30c5da78acc8##
<h1>Orders</h1><br>
<table class="table table-striped 
	table-responsive table-condensed small">
	<thead>
		<tr>
			<th>OrderId</th>
			<th>Account</th>
			<th>Status</th>
			<th>Created</th>
		</tr>
	</thead>
	<tbody>
		<tr v-for="order in orders">
			<td>{{order.Order_Num}}</td>
			<td>{{order.Account}}</td>
			<td>{{order.Status}}</td>
			<td>{{order.Created}}</td>
		</tr>
	</tbody>
</table>






<?php $__env->stopSection(); ?>
<?php echo $__env->make("template", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>