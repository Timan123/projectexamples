<!DOCTYPE HTML>
<html>
<head>

	
	
	<?php $__env->startSection('title'); ?> Cogent <?php $__env->stopSection(); ?>
	<?php $__env->startSection('brand-title'); ?> Cogent <?php $__env->stopSection(); ?>
	<?php $__env->startSection('containerClass'); ?><?php echo e((isset($useFluidContainer) && $useFluidContainer === true) ? 'container-fluid' : 'container'); ?><?php $__env->stopSection(); ?>

	<?php $__env->startSection('cssCacheBuster'); ?>
	

	<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php $__env->startSection('meta'); ?>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="Cogent">
	<meta name="description" content="Cogent">
	<link rel="shortcut icon" href="favicon.png">
	<?php $__env->stopSection(); ?>

	<title><?php echo e(trim(View::yieldContent('title'))); ?></title>
	<?php echo $__env->yieldContent('meta'); ?>

	
	
</head>
<body>
	<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
		<div class="<?php echo e(trim(View::yieldContent('containerClass'))); ?>">
			<div class="navbar-header">
				<a href="/" class="navbar-brand">Fiber</a>
			</div>
			<div id="navbar" class="navbar-collapse collapse">
				<ul class="nav navbar-nav">
				    <li <?php echo e((Request::is('rings') ? 'class=active' : '')); ?>>
					    <a href="rings">Rings</a>
				    </li>
					<li  <?php echo e((Request::is('laterals') ? 'class=active' : '')); ?>>
					    <a href="laterals">Laterals</a>
				    </li>

				</ul>
				<ul class="nav navbar-nav pull-right">
					<?php if( !Auth::check() ): ?>
					<li>
						<a href="login" >Login</a>
					</li>
					<?php else: ?>
					
					<li>
						<a aria-expanded="false" href="#" class="dropdown-toggle" data-toggle="dropdown">
							<span class="glyphicon glyphicon-user"></span> <?php echo e(Auth::user()->getCommonName()); ?> 
						</a>
					</li>	
					<li>
						<a href="logout"><span class="glyphicon glyphicon-share fa-fw"></span>Logout</a>
					</li>
					<?php endif; ?>
				</ul>
			</div>

		</div>
	</nav>

	<div class="<?php echo e(trim(View::yieldContent('containerClass'))); ?>" id="main">
		<?php echo $__env->yieldContent('content'); ?>
		
		
		
		
	</div>

	<footer class="<?php echo e(trim(View::yieldContent('containerClass'))); ?>">
		<?php $__env->startSection('footer'); ?>
		<?php if(session()->has('message')): ?>
		<div class="alert alert-success">
			<?php echo e(session()->get('message')); ?>

		</div>	
		<?php endif; ?>
		<?php if(session()->has('warning')): ?>
		<div class="alert alert-warning">
			<?php echo e(session()->get('warning')); ?>

		</div>	
		<?php endif; ?>
		<p class="text-center">
			&copy; <?php echo e(\Carbon\Carbon::now()->year); ?> Cogent Communications, Inc.
			<?php if( defined('VERSION') ): ?>
			|&nbsp; v<?php echo e(constant('VERSION')); ?>

			<?php endif; ?>
		</p>
		<?php $__env->stopSection(); ?>

		<?php echo $__env->yieldContent('footer'); ?>
	</footer>

	<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>