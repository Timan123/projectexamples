<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::get('/ringNameAuto', 'APIController@ringNameAuto');



Route::get('/getRingData', 'APIController@getRingData');

Route::get('/getLateralData', 'APIController@getLateralData');

Route::post('/saveRing', 'ActionController@saveRing');



//DROPDOWNS
Route::get('/rings', 'APIController@rings');
Route::get('/laterals', 'APIController@laterals');
Route::get('/fiberProviders', 'APIController@fiberProviders');
Route::get('/contractStatuses', 'APIController@contractStatuses');

Route::get('/markets', 'APIController@markets');
Route::get('/connectionStatuses', 'APIController@connectionStatuses');
Route::get('/currencies', 'APIController@currencies');
