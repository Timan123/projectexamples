<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

	Route::group([ 'prefix' => 'login' ], function()
	{
		Route::get('/', [ 'as' => 'login.form', 'uses' => 'PageController@login' ]);
		Route::post('/', [ 'as' => 'login', 'uses' => 'LoginController@login' ]);

		//Route::any('forgot', [ 'as' => 'login.forgot', 'uses' => 'LoginController@forgot' ]);
	});
	Route::get('logout','LoginController@logout');


Route::get('/', function () {
    return Redirect::route('rings.index');
});

Route::get('/vue', function () {
    return view('vue');
});

Route::get('rings', [ 'as' => 'rings.index', 'uses' => 'PageController@rings' ])->middleware('auth');

Route::get('laterals', [ 'as' => 'laterals.index', 'uses' => 'PageController@laterals' ])->middleware('auth');

//post routes are for form submits
Route::post('/rings', 'ActionController@saveRing');

Route::post('/laterals', 'ActionController@saveLateral');

Route::get('/orders', function () {
    return view('orders');
});
//
//Auth::routes();
//
//Route::get('/home', 'HomeController@index')->name('home');
